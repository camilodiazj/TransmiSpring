package com.sophos.transmilenio.daos;

import org.springframework.data.repository.CrudRepository;

import com.sophos.transmilenio.beans.Ruta;

public interface RutaDao extends CrudRepository<Ruta, String>{

}
