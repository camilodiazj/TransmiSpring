package com.sophos.transmilenio.daos;

import org.springframework.data.repository.CrudRepository;

import com.sophos.transmilenio.beans.Troncal;

public interface TroncalDao extends CrudRepository<Troncal, String>{

}
