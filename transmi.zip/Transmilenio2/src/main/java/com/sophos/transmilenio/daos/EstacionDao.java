package com.sophos.transmilenio.daos;

import org.springframework.data.repository.CrudRepository;

import com.sophos.transmilenio.beans.Estacion;

public interface EstacionDao extends CrudRepository<Estacion, String>{

}
